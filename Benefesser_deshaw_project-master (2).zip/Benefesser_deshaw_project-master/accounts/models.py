from django.db import models
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    is_charity=models.BooleanField(default=False)
    balance = models.IntegerField(default = 0)