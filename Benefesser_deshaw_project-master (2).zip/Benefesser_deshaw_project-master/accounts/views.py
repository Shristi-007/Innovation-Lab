from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
# Create your views here.
from django.contrib import auth

from UserPage.views import profile_page
from .models import *
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .forms import CreateUserForm
# from .forms import CreateCharityForm
from UserPage.models import Payments
from explore.models import Charity

def user_r(request):
    form = CreateUserForm()
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            USER = form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'Account was created for ' + user)
            # instance = balance(user = USER, balance = 0)
            # instance.save()
            return redirect('/login')
        else:
            print(form.errors)

    context = {'form': form}
    return render(request, 'user_registration.html', context)

def payment(request):
    context = {
        'posts' : Charity.objects.all(),
    }
    return render(request, 'payment.html', context)

def donating(request):
    query = request.POST.get('subtracting', False)
    print( "QUERY: ")
    print(query)
    #t = loader.get_template('explore.html')
    flag_4_failure =0
    # t = balance.objects.all().filter(user=request.user)
    t = User.objects.all()
    for tt in t:
        print(tt)
        if int(query) > tt.balance :
            flag_4_failure =1
            break
        tt.balance -= int(query)  # change field
        tt.save() # this will update only

    #   return HttpResponse(t.render(c))
    # user = balance.objects.get(user=request.user)
    user = request.user

    context = {
        'balance': user.balance,
        'posts' : flag_4_failure
    }
    return render(request, 'user_page.html',context)

def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            if username == "vani":
                return redirect('/AdminApprovalView')
            if user.is_charity:
                return redirect('/lolz')
            return redirect('/explore')
        else:
            messages.info(request, 'Username OR password is incorrect')

    context = {}
    return render(request, 'login.html', context)


def logout_user(request):
    auth.logout(request)
    return redirect('/')


def charity_r(request):
    if request.method == 'POST':
        organisation_name = request.POST['name']
        year = request.POST['year']
        location = request.POST['location']
        theme = request.POST['charity_theme']
        rating = request.POST['rating']
        pic_link = request.POST['pic_link']
        document = request.POST['certificate']
        email = request.POST['email']
        name = request.POST['name']
        username = request.POST['username']
        password = request.POST['password']
        password2 = request.POST['password2']

        if(password != password2):
            messages.info(request, 'Password not matching')
            return redirect('charity_r')
        
        if User.objects.filter(username=username).exists():
            messages.info(request, 'Username taken')
            return redirect('charity_r')
        
        if User.objects.filter(email=email).exists():
            messages.info(request, 'Email taken')
            return redirect('charity_r')

        user = User.objects.create_user(username, email, password)
        user.first_name = name
        user.is_charity = True
        user.save()
        CharityInfo = Charity(name=organisation_name, year=year, location=location, charity_theme=theme, rating=rating,
                              pic_link=pic_link, certificate=document, user=user, email=email)
        CharityInfo.save()
        messages.success(request, 'Account was created for ' + username)
        return redirect('/login')

    return render(request, 'Charity_registration.html')