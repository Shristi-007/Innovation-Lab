from django.db import models
from accounts.models import User
from django.contrib.postgres.fields import ArrayField
# Create your models here.

class Charity(models.Model):
    name = models.CharField(max_length=250)
    location = models.CharField(max_length=50)
    year = models.CharField(max_length=4)
    charity_theme = models.CharField(max_length=250)
    rating = models.DecimalField(max_digits=2, decimal_places=1)
    pic_link = models.CharField(max_length=1000)
    charity_id = models.CharField(max_length=7, )
    certificate = models.ImageField(upload_to="media", blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    identifier = models.CharField(max_length=40)
    email = models.EmailField()
    status = models.IntegerField(default=0)
    # payments=ArrayField( 
    #     ArrayField(
    #         models.IntegerField(default=0),
    #         max_length=2,
    #     )
    # ) # store id of user & balance in this array use postgresql [[id,amt]]
    def __str__(self) -> str:
        return self.name + ' - ' + str(self.rating)

    def get_queryset(self):
        return Charity.objects.all().orderby('-rating')
