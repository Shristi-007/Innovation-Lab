from django.shortcuts import render
from .models import Payments
from accounts.models import User

# Create your views here.
def profile_page(request):
    context = {
        'posts': Payments.objects.all().filter(user=request.user),
        # 'posts' : posts
    }
    # user = balance.objects.get(user=request.user)
    user =  request.user.balance
    if user is not None:
        return render(request, 'user_page.html',{"balance":user.balance})
    else:
        return render(request, 'user_page.html')


def addmoney(request):
    context = {
        'posts': Payments.objects.all().filter(user=request.user),
        # 'posts' : posts
    }
    
    return render(request, 'add_money.html',context)

def adding(request):
    query = request.POST.get('adding', False)
    print( "QUERY: ")
    print(query)
    #t = loader.get_template('explore.html')
    
    user=User.objects.get(username=request.user)
    user.balance += int(query)  # change field
    user.save()
    #   return HttpResponse(t.render(c))
    return profile_page(request)