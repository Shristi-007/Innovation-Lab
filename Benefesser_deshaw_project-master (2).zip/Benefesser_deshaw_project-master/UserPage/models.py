from django.db import models

# Create your models here.
from accounts.models import User
from explore.models import Charity

class Payments(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,)
    charity= models.ForeignKey(Charity,on_delete=models.CASCADE,)
    amt = models.IntegerField(default = 0)

